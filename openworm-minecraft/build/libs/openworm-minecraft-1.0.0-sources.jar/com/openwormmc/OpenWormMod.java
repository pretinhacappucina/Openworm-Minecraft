package com.openwormmc;

import com.openwormmc.commands.OpenWormCommand;
import com.openwormmc.entity.CElegansEntity;
import com.openwormmc.entity.SimulationService;
import com.openwormmc.net.BrainPackets;
import com.openwormmc.registry.ModRegistry;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_3222;

public class OpenWormMod implements ModInitializer {
    @Override public void onInitialize() {
        ModRegistry.init(); OpenWormCommand.register();
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> SimulationService.INSTANCE.shutdown());
        // every 5 ticks, send the nearest worm's snapshot to each player within 48 blocks (viewer only)
        ServerTickEvents.END_SERVER_TICK.register(server -> { if (server.method_3780() % 5 != 0) return;
            for (var p : server.method_3760().method_14571())
                p.method_37908().method_8390(CElegansEntity.class, p.method_5829().method_1014(48), e -> true).stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.method_5858(p))).ifPresent(w -> BrainPackets.send(p, w)); });
    }
}
