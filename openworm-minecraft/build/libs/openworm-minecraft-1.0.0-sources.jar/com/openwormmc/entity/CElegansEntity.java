package com.openwormmc.entity;

import com.openwormmc.brain.Brain;
import com.openwormmc.brain.Brain.Snapshot;
import com.openwormmc.sensors.SensorMap;
import com.openwormmc.sensors.SensorMap.Channel;
import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * C. elegans. Server side: samples Minecraft stimuli -> SensorMap (documented approximations), lets the shared
 * SimulationService step the Brain, then moves the entity with the velocity SOLVED by the body physics
 * (resistive force theory) from muscle-driven curvature. There is no behaviour state machine.
 * AUXILIARY (not emergent): the Minecraft collision/odour sampling, and WORLD_SPEED_GAIN that maps body-lengths per
 * simulated second to blocks per tick (the simulation runs slower than real time; see README).
 * UNCOMPILED in the build environment.
 */
public class CElegansEntity extends class_1314 {
    public static final double BODY_LENGTH_BLOCKS = 1.0, ODOR_RANGE = 10, WORLD_SPEED_GAIN = 8.0;
    /** joint angles of the 11 joints, quantised to 1/100 rad and sent to the client as a string (render only) */
    public static final class_2940<String> SHAPE = class_2945.method_12791(CElegansEntity.class, class_2943.field_13326);
    private Brain brain; private boolean registered;
    private double lastHeading; private long feedUntil;

    public CElegansEntity(class_1299<? extends class_1314> type, class_1937 world) { super(type, world); }
    public static class_5132.class_5133 attributes() { return class_1314.method_26828().method_26868(class_5134.field_23716, 4.0).method_26868(class_5134.field_23719, 0.1); }
    @Override protected void method_5693() { super.method_5693(); field_6011.method_12784(SHAPE, ""); }
    public Brain brain() { return brain; }

    @Override public void method_5773() {
        super.method_5773();
        if (method_37908().field_9236) return;
        SimulationService svc = SimulationService.INSTANCE;
        if (!registered) { brain = new Brain(); registered = svc.register(method_5628(), brain); if (!registered) { method_31472(); return; } lastHeading = method_36454(); }
        sampleStimuli(brain.sensors);
        svc.requestTick(method_5628());
        var snap = brain.snapshot();
        // body solved velocity (BL/ms) -> blocks/tick ; direction = body heading relative to spawn yaw
        double speedBlocksPerTick = brain.body.forwardSpeed() * brain.simMsPerTick * BODY_LENGTH_BLOCKS * WORLD_SPEED_GAIN;
        float yaw = (float) (lastHeading - Math.toDegrees(snap.heading));
        method_36456(yaw); method_5636(yaw); method_5847(yaw);
        double rad = Math.toRadians(yaw);
        class_243 v = new class_243(-Math.sin(rad) * speedBlocksPerTick, method_18798().field_1351, Math.cos(rad) * speedBlocksPerTick);
        method_18799(v); field_6037 = true;
        StringBuilder sb = new StringBuilder(); for (double t : brain.body.theta) sb.append(Math.round(t * 100)).append(',');
        field_6011.method_12778(SHAPE, sb.toString());
    }

    /** AUXILIARY sensing: Minecraft world -> stimulus intensities (0..1). */
    private void sampleStimuli(SensorMap s) {
        s.set(Channel.HEAD_TOUCH, field_5976 ? 1 : 0);
        s.set(Channel.BODY_TOUCH, 0); s.set(Channel.TAIL_TOUCH, 0);
        double yawRad = Math.toRadians(method_36454()); class_243 fwd = new class_243(-Math.sin(yawRad), 0, Math.cos(yawRad)), left = new class_243(fwd.field_1350, 0, -fwd.field_1352);
        class_2338 c = method_24515(); double bestL = 0, bestR = 0, bestD = 1e9; int r = (int) ODOR_RANGE;
        for (class_2338 p : class_2338.method_25996(c, r, 2, r)) {
            if (!method_37908().method_8320(p).method_27852(com.openwormmc.registry.ModRegistry.BACTERIAL_COLONY)) continue;
            class_243 d = class_243.method_24953(p).method_1020(method_19538()); double dist = d.method_1033(); bestD = Math.min(bestD, dist);
            double conc = SensorMap.odor(dist, ODOR_RANGE); double side = d.method_1026(left) / Math.max(dist, 1e-6);
            bestL += conc * (0.5 + 0.5 * side); bestR += conc * (0.5 - 0.5 * side);
        }
        s.set(Channel.ODOR_LEFT, Math.min(1, bestL)); s.set(Channel.ODOR_RIGHT, Math.min(1, bestR));
        s.set(Channel.FOOD_CONTACT, bestD < 1.2 ? 1 : 0);
        if (method_37908().method_8510() < feedUntil) { s.set(Channel.ODOR_LEFT, 1); s.set(Channel.ODOR_RIGHT, 1); s.set(Channel.FOOD_CONTACT, 1); }
    }
    /** Debug/command hook: experimental food stimulus applied to this worm. */
    public void feedStimulus() { feedUntil = method_37908().method_8510() + 100; }

    @Override public void method_5650(class_5529 reason) { if (!method_37908().field_9236 && registered) SimulationService.INSTANCE.unregister(method_5628()); super.method_5650(reason); }
}
