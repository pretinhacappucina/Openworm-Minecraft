package com.openwormmc.entity;

import net.minecraft.class_2248;

/** Food source. CElegansEntity scans for this block to build the odour stimulus (see SensorMap.odor). */
public class BacterialColonyBlock extends class_2248 {
    public BacterialColonyBlock(class_2251 settings) { super(settings); }
}
