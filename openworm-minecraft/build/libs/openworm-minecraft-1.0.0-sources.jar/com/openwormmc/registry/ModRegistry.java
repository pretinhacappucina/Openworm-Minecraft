package com.openwormmc.registry;

import com.openwormmc.entity.CElegansEntity;
import com.openwormmc.entity.BacterialColonyBlock;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.item.*;

/** UNCOMPILED in the build environment (Fabric/Minecraft artifacts were unreachable). Written for Fabric 1.20.1 / Yarn. */
public final class ModRegistry {
    public static final String MOD_ID = "openwormmc";
    public static class_1299<CElegansEntity> C_ELEGANS;
    public static class_2248 BACTERIAL_COLONY;
    public static class_1792 BACTERIAL_COLONY_ITEM, SPAWN_EGG;

    public static void init() {
        C_ELEGANS = class_2378.method_10230(class_7923.field_41177, new class_2960(MOD_ID, "c_elegans"),
            FabricEntityTypeBuilder.create(class_1311.field_6294, CElegansEntity::new).dimensions(class_4048.method_18385(1.0f, 0.15f)).trackRangeBlocks(48).build());
        FabricDefaultAttributeRegistry.register(C_ELEGANS, CElegansEntity.attributes());
        BACTERIAL_COLONY = class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "bacterial_colony"),
            new BacterialColonyBlock(class_4970.class_2251.method_9637().method_9632(0.3f).method_9626(net.minecraft.class_2498.field_11545)));
        BACTERIAL_COLONY_ITEM = class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "bacterial_colony"), new class_1747(BACTERIAL_COLONY, new class_1792.class_1793()));
        SPAWN_EGG = class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "c_elegans_spawn_egg"), new class_1826(C_ELEGANS, 0xE8DCC0, 0x7A6A4F, new class_1792.class_1793()));
        ItemGroupEvents.modifyEntriesEvent(net.minecraft.class_7706.field_40205).register(e -> e.method_45421(SPAWN_EGG));
        ItemGroupEvents.modifyEntriesEvent(net.minecraft.class_7706.field_40743).register(e -> e.method_45421(BACTERIAL_COLONY_ITEM));
    }
}
