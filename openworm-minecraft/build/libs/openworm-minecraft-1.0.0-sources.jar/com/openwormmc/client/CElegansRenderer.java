package com.openwormmc.client;

import com.openwormmc.entity.CElegansEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.client.model.*;

/** 12 articulated segments; each joint angle comes from the server (brain->muscle->body). UNCOMPILED in the build environment. */
public class CElegansRenderer extends class_897<CElegansEntity> {
    public static final class_5601 LAYER = new class_5601(new class_2960("openwormmc", "c_elegans"), "main");
    private static final class_2960 TEX = new class_2960("openwormmc", "textures/entity/c_elegans.png");
    private final class_630 seg, head;

    public CElegansRenderer(class_5617.class_5618 ctx) { super(ctx); class_630 root = ctx.method_32167(LAYER); seg = root.method_32086("seg"); head = root.method_32086("head"); }

    public static class_5607 createModel() {
        class_5609 md = new class_5609(); class_5610 r = md.method_32111();
        r.method_32117("seg", class_5606.method_32108().method_32101(0, 0).method_32097(-1.5f, -1.5f, -2.5f, 3, 3, 5), class_5603.field_27701);
        r.method_32117("head", class_5606.method_32108().method_32101(0, 8).method_32097(-1.0f, -1.0f, -2.0f, 2, 2, 4), class_5603.field_27701);
        return class_5607.method_32110(md, 32, 16);
    }

    @Override public void render(CElegansEntity e, float yaw, float dt, class_4587 m, class_4597 vp, int light) {
        String s = e.method_5841().method_12789(CElegansEntity.SHAPE); String[] a = s.isEmpty() ? new String[0] : s.split(",");
        m.method_22903(); m.method_22904(0, 0.1, 0); m.method_22907(class_7833.field_40716.rotationDegrees(180 - yaw));
        var vc = vp.getBuffer(class_1921.method_23576(TEX)); float seglen = 1.0f / 12; double phi = 0, px = 0, pz = 0;
        for (int i = 0; i < 12; i++) {
            if (i > 0 && i - 1 < a.length) phi += Integer.parseInt(a[i - 1]) / 100.0;
            m.method_22903(); m.method_22904(px, 0, pz); m.method_22907(class_7833.field_40716.rotation((float) phi)); m.method_22905(seglen * 16f / 5f * 0.0625f * 5f, 0.06f, seglen * 16f / 5f * 0.0625f * 5f);
            (i == 0 ? head : seg).method_22698(m, vc, light, class_4608.field_21444); m.method_22909();
            px += Math.sin(phi) * seglen; pz += Math.cos(phi) * seglen;
        }
        m.method_22909(); super.method_3936(e, yaw, dt, m, vp, light);
    }
    @Override public class_2960 getTexture(CElegansEntity e) { return TEX; }
}
