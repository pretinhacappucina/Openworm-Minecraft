package com.openwormmc.commands;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.openwormmc.brain.Brain;
import com.openwormmc.brain.Brain.Snapshot;
import com.openwormmc.entity.CElegansEntity;
import com.openwormmc.entity.SimulationService;
import com.openwormmc.registry.ModRegistry;
import java.util.List;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_238;
import net.minecraft.class_2561;

/** /openworm spawn [n] | stats | brain | debug | feed | pause | resume. UNCOMPILED in the build environment. */
public final class OpenWormCommand {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((d, access, env) -> d.register(method_9247("openworm").requires(s -> s.method_9259(2))
            .then(method_9247("spawn").executes(c -> spawn(c, 1)).then(method_9244("n", IntegerArgumentType.integer(1, 50)).executes(c -> spawn(c, IntegerArgumentType.getInteger(c, "n")))))
            .then(method_9247("stats").executes(OpenWormCommand::stats))
            .then(method_9247("brain").executes(OpenWormCommand::brain))
            .then(method_9247("debug").executes(c -> { SimulationService s = SimulationService.INSTANCE; s.debug = !s.debug; msg(c, "debug=" + s.debug); return 1; }))
            .then(method_9247("feed").executes(c -> { int k = 0; for (var w : worms(c)) { w.feedStimulus(); k++; } msg(c, "food stimulus sent to " + k + " worm(s)"); return k; }))
            .then(method_9247("pause").executes(c -> { SimulationService.INSTANCE.paused = true; msg(c, "paused"); return 1; }))
            .then(method_9247("resume").executes(c -> { SimulationService.INSTANCE.paused = false; msg(c, "resumed"); return 1; }))));
    }
    private static java.util.List<CElegansEntity> worms(CommandContext<class_2168> c) {
        var src = c.getSource(); return src.method_9225().method_8390(CElegansEntity.class, new class_238(src.method_9222(), src.method_9222()).method_1014(128), e -> true);
    }
    private static void msg(CommandContext<class_2168> c, String s) { c.getSource().method_9226(() -> class_2561.method_43470("[OpenWorm] " + s), false); }
    private static int spawn(CommandContext<class_2168> c, int n) {
        var src = c.getSource(); int ok = 0;
        for (int i = 0; i < n; i++) { var e = ModRegistry.C_ELEGANS.method_5883(src.method_9225()); if (e == null) continue;
            e.method_5808(src.method_9222().field_1352 + (i % 5) * 1.5, src.method_9222().field_1351, src.method_9222().field_1350 + (i / 5) * 1.5, src.method_9225().field_9229.method_43057() * 360f, 0f);
            if (src.method_9225().method_8649(e)) ok++; }
        msg(c, "spawned " + ok + " C. elegans (max active brains " + SimulationService.INSTANCE.maxActiveBrains + ")"); return ok;
    }
    private static int stats(CommandContext<class_2168> c) {
        var s = SimulationService.INSTANCE; msg(c, String.format("brains=%d paused=%b updates/s=%.1f uptime=%.0fs", s.count(), s.paused, s.updateHz(), s.uptimeSeconds())); return 1;
    }
    private static int brain(CommandContext<class_2168> c) {
        var l = worms(c); if (l.isEmpty() || l.get(0).brain() == null) { msg(c, "no worm nearby"); return 0; }
        Brain b = l.get(0).brain(); var s = b.snapshot();
        msg(c, String.format("model=c302 C1-style (Cook 2019) neurons=%d chemical+neuromuscular synapses=%d gap=%d active=%d simTime=%.0fms",
            b.cx.neurons.length, b.net.chemicalSynapseCount(), b.net.gapJunctionCount(), s.active, s.timeMs)); return 1;
    }
}
